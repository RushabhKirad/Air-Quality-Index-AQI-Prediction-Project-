import joblib
import pandas as pd
import os
import logging

# ✅ Ensure Required Folders Exist
os.makedirs("app/model", exist_ok=True)
os.makedirs("app/logs", exist_ok=True)

# ✅ Paths
MODEL_PATH = "app/model/model.pkl"
FEEDBACK_PATH = "app/feedback.csv"
ERROR_LOG_PATH = "app/logs/error_log.txt"

# ✅ Setup Logging (all errors logged into error_log.txt)
logging.basicConfig(
    filename=ERROR_LOG_PATH,
    level=logging.ERROR,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# 1️⃣ Load Model
def load_model():
    try:
        model = joblib.load(MODEL_PATH)
        return model
    except Exception as e:
        log_error(f"❌ Model Load Error: {e}")
        return None

# 2️⃣ Predict AQI
def predict_aqi(model, input_data):
    try:
        input_df = pd.DataFrame([input_data])
        prediction = model.predict(input_df)[0]
        return prediction
    except Exception as e:
        log_error(f"❌ Prediction Error: {e}")
        return None

# 3️⃣ Collect Feedback (Flexible to Handle Rating/Usefulness/Comments)
def collect_feedback(predicted_aqi, useful, rating, comment):
    feedback_data = {
        "timestamp": pd.Timestamp.now(),
        "predicted_AQI": predicted_aqi,
        "useful": useful,
        "rating": rating,
        "comment": comment
    }
    df = pd.DataFrame([feedback_data])

    if os.path.exists(FEEDBACK_PATH):
        df.to_csv(FEEDBACK_PATH, mode='a', header=False, index=False)
    else:
        df.to_csv(FEEDBACK_PATH, index=False)

# 4️⃣ Error Logging Function
def log_error(message):
    logging.error(message)

# 5️⃣ AQI Category & Color Mapping (Aligned with CPCB Standards)
def get_aqi_category(aqi):
    if 0 <= aqi <= 50:
        return "Good", "#009966"  # Green
    elif 51 <= aqi <= 100:
        return "Satisfactory", "#FFDE33"  # Yellow
    elif 101 <= aqi <= 200:
        return "Moderate", "#FF9933"  # Orange
    elif 201 <= aqi <= 300:
        return "Poor", "#CC0033"  # Red-Orange
    elif 301 <= aqi <= 400:
        return "Very Poor", "#660099"  # Purple
    elif 401 <= aqi <= 500:
        return "Severe", "#7E0023"  # Maroon
    else:
        return "Invalid AQI", "#FFFFFF"  # Fallback color (white)
