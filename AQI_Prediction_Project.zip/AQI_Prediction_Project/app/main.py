import os
from datetime import datetime
import streamlit as st
from utils import load_model, predict_aqi, collect_feedback, log_error, get_aqi_category

# Load the trained model
model = load_model()

if model is None:
    st.error("🔴 Error loading the model. Please check logs for more details.")
    st.stop()

# Page Title
st.title("🌍 Air Quality Index (AQI) Prediction")
st.write("Predict AQI based on pollution levels and meteorological factors.")

# User Input Form
st.sidebar.header("📥 Enter Data")

# Inputs with proper types
PM25 = st.sidebar.number_input('PM2.5 (µg/m³)', min_value=0.0, value=50.0)
PM10 = st.sidebar.number_input('PM10 (µg/m³)', min_value=0.0, value=100.0)
NO2 = st.sidebar.number_input('NO2 (µg/m³)', min_value=0.0, value=40.0)
NH3 = st.sidebar.number_input('NH3 (µg/m³)', min_value=0.0, value=20.0)
SO2 = st.sidebar.number_input('SO2 (µg/m³)', min_value=0.0, value=15.0)
CO = st.sidebar.number_input('CO (mg/m³)', min_value=0.0, value=0.7)
O3 = st.sidebar.number_input('O3 (µg/m³)', min_value=0.0, value=30.0)

# Date-based Features
month = st.sidebar.selectbox('Month', list(range(1, 13)))
weekend = st.sidebar.radio('Is it Weekend?', ['No', 'Yes'])
weekend = 1 if weekend == 'Yes' else 0

# Historical AQI Input
previous_day_aqi = st.sidebar.number_input('Previous Day AQI', min_value=0.0, value=150.0)

# Derived Features
PM25_PM10 = PM25 / PM10 if PM10 != 0 else 0
NO2_SO2 = NO2 / SO2 if SO2 != 0 else 0

# Predict AQI Button
if st.sidebar.button("🔍 Predict AQI"):
    # Prepare Input Dictionary
    input_data = {
        'PM2.5': PM25,
        'PM10': PM10,
        'NO2': NO2,
        'NH3': NH3,
        'SO2': SO2,
        'CO': CO,
        'O3': O3,
        'Month': month,
        'Weekend': weekend,
        'PM2.5/PM10': PM25_PM10,
        'NO2/SO2': NO2_SO2,
        'Previous_Day_AQI': previous_day_aqi
    }

    # Predict AQI
    predicted_aqi = predict_aqi(model, input_data)

    if predicted_aqi is not None:
        category, color = get_aqi_category(predicted_aqi)

        st.markdown(
            f"""
            <div style="
                padding: 15px;
                border-radius: 10px;
                background-color: {color};
                color: black;
                font-weight: bold;
                font-size: 18px;
                text-align: center;">
                Air Quality Index (AQI): {predicted_aqi:.2f}<br>
                Category: {category}
            </div>
            """,
            unsafe_allow_html=True
        )
    else:
        st.error("❌ Failed to predict AQI. Please check error logs.")
    

# Footer
st.write("---")
st.write("🔧 Built for Internship Selection - Advanced AQI Predictor 2025")
